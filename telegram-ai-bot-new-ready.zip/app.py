import asyncio
import base64
import logging
import os
import time
from collections import deque
from contextlib import asynccontextmanager
from typing import Any

import httpx
from fastapi import FastAPI, HTTPException, Request
from openai import AsyncOpenAI

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("telegram-ai-bot")

TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "").strip()
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-5.6-luna").strip()

TELEGRAM_API = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}" if TELEGRAM_BOT_TOKEN else ""
MAX_FILE_BYTES = 15 * 1024 * 1024
MAX_TEXT_CHARS = 12000
MAX_TELEGRAM_CHARS = 3900
POLL_TIMEOUT = 30
PROCESSED_LIMIT = 1000

openai_client = AsyncOpenAI(api_key=OPENAI_API_KEY) if OPENAI_API_KEY else None
processed_updates = deque(maxlen=PROCESSED_LIMIT)
processed_set: set[int] = set()
stop_event = asyncio.Event()


def configured() -> bool:
    return bool(TELEGRAM_BOT_TOKEN and OPENAI_API_KEY and openai_client)


def remember_update(update_id: int) -> bool:
    if update_id in processed_set:
        return False
    if len(processed_updates) == processed_updates.maxlen:
        old = processed_updates[0]
        processed_set.discard(old)
    processed_updates.append(update_id)
    processed_set.add(update_id)
    return True


async def telegram(method: str, payload: dict[str, Any] | None = None) -> dict[str, Any]:
    if not TELEGRAM_BOT_TOKEN:
        raise RuntimeError("TELEGRAM_BOT_TOKEN is not configured")
    async with httpx.AsyncClient(timeout=60) as client:
        r = await client.post(f"{TELEGRAM_API}/{method}", json=payload or {})
        r.raise_for_status()
        data = r.json()
        if not data.get("ok"):
            raise RuntimeError(f"Telegram API error: {data}")
        return data


async def send_message(chat_id: int, text: str) -> None:
    text = text or "Пустой ответ."
    for start in range(0, len(text), MAX_TELEGRAM_CHARS):
        await telegram("sendMessage", {
            "chat_id": chat_id,
            "text": text[start:start + MAX_TELEGRAM_CHARS],
        })


async def typing(chat_id: int) -> None:
    try:
        await telegram("sendChatAction", {"chat_id": chat_id, "action": "typing"})
    except Exception:
        log.exception("Could not send typing action")


async def download_file(file_id: str) -> tuple[bytes, str]:
    info = await telegram("getFile", {"file_id": file_id})
    file_path = info["result"]["file_path"]
    url = f"https://api.telegram.org/file/bot{TELEGRAM_BOT_TOKEN}/{file_path}"
    async with httpx.AsyncClient(timeout=60) as client:
        r = await client.get(url)
        r.raise_for_status()
        data = r.content
    if len(data) > MAX_FILE_BYTES:
        raise ValueError("Файл слишком большой. Максимальный размер для этого бота — 15 МБ.")
    return data, file_path


def to_data_url(data: bytes, file_path: str) -> str:
    ext = file_path.rsplit(".", 1)[-1].lower() if "." in file_path else "jpg"
    mime = {
        "jpg": "image/jpeg",
        "jpeg": "image/jpeg",
        "png": "image/png",
        "webp": "image/webp",
    }.get(ext)
    if not mime:
        raise ValueError("Поддерживаются изображения JPG, JPEG, PNG и WEBP.")
    encoded = base64.b64encode(data).decode("ascii")
    return f"data:{mime};base64,{encoded}"


async def ask_openai(text: str | None = None, image_url: str | None = None) -> str:
    if not openai_client:
        raise RuntimeError("OPENAI_API_KEY is not configured")

    content: list[dict[str, Any]] = []
    if text:
        content.append({"type": "input_text", "text": text[:MAX_TEXT_CHARS]})
    if image_url:
        content.append({"type": "input_image", "image_url": image_url})
    if not content:
        content.append({
            "type": "input_text",
            "text": "Проанализируй изображение подробно и ответь по-русски.",
        })

    response = await openai_client.responses.create(
        model=OPENAI_MODEL,
        input=[{"role": "user", "content": content}],
    )
    answer = (response.output_text or "").strip()
    return answer or "Не удалось получить ответ от ИИ."


async def handle_update(update: dict[str, Any]) -> None:
    update_id = update.get("update_id")
    if isinstance(update_id, int) and not remember_update(update_id):
        return

    message = update.get("message")
    if not message:
        return

    chat_id = message.get("chat", {}).get("id")
    if not chat_id:
        return

    try:
        text = (message.get("text") or "").strip()

        if text == "/start":
            await send_message(
                chat_id,
                "Привет! Я ИИ-ассистент.\n\n"
                "Отправь текст или фотографию. Фото можно отправить с подписью, "
                "например: «Реши задачу на фото».\n\n"
                "Команды: /start, /help",
            )
            return

        if text == "/help":
            await send_message(
                chat_id,
                "Я умею обрабатывать текст и изображения. "
                "Отправь сообщение или фото с вопросом.",
            )
            return

        await typing(chat_id)

        if text:
            answer = await ask_openai(text=text)
            await send_message(chat_id, answer)
            return

        photo = message.get("photo")
        document = message.get("document")

        if photo:
            file_id = photo[-1]["file_id"]
            data, path = await download_file(file_id)
            caption = (message.get("caption") or "").strip()
            answer = await ask_openai(
                text=caption or "Подробно проанализируй это изображение и ответь по-русски.",
                image_url=to_data_url(data, path),
            )
            await send_message(chat_id, answer)
            return

        if document and (document.get("mime_type") or "").lower() in {
            "image/jpeg", "image/png", "image/webp"
        }:
            data, path = await download_file(document["file_id"])
            caption = (message.get("caption") or "").strip()
            answer = await ask_openai(
                text=caption or "Подробно проанализируй это изображение и ответь по-русски.",
                image_url=to_data_url(data, path),
            )
            await send_message(chat_id, answer)
            return

        await send_message(chat_id, "Отправь текст или изображение JPG, PNG либо WEBP.")

    except Exception:
        log.exception("Update processing failed")
        try:
            await send_message(chat_id, "Произошла ошибка при обработке. Попробуй ещё раз.")
        except Exception:
            log.exception("Could not send error message")


async def polling_loop() -> None:
    if not TELEGRAM_BOT_TOKEN:
        log.warning("Telegram token is missing; polling is disabled.")
        return

    offset = 0
    try:
        me = await telegram("getMe")
        log.info("Telegram bot connected: @%s", me["result"].get("username"))
    except Exception:
        log.exception("Telegram getMe failed")
        return

    # Remove any old queued updates. This prevents a newly deployed bot from
    # processing messages that were sent while it was offline.
    try:
        data = await telegram("getUpdates", {"offset": -1, "timeout": 1, "allowed_updates": ["message"]})
        if data.get("result"):
            offset = data["result"][-1]["update_id"] + 1
    except Exception:
        log.exception("Initial Telegram polling check failed")

    while not stop_event.is_set():
        try:
            data = await telegram(
                "getUpdates",
                {
                    "offset": offset,
                    "timeout": POLL_TIMEOUT,
                    "allowed_updates": ["message"],
                },
            )
            for update in data.get("result", []):
                offset = max(offset, update["update_id"] + 1)
                asyncio.create_task(handle_update(update))
        except asyncio.CancelledError:
            raise
        except Exception:
            log.exception("Telegram polling error")
            await asyncio.sleep(5)


@asynccontextmanager
async def lifespan(_: FastAPI):
    stop_event.clear()
    task = None
    if TELEGRAM_BOT_TOKEN and OPENAI_API_KEY:
        task = asyncio.create_task(polling_loop())
    yield
    stop_event.set()
    if task:
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass


app = FastAPI(title="Telegram AI Bot", version="2.0.0", lifespan=lifespan)


@app.get("/")
async def root() -> dict[str, str]:
    return {"status": "ok", "service": "telegram-ai-bot", "mode": "polling"}


@app.get("/health")
async def health() -> dict[str, Any]:
    return {
        "status": "ok",
        "telegram_configured": bool(TELEGRAM_BOT_TOKEN),
        "openai_configured": bool(OPENAI_API_KEY),
        "model": OPENAI_MODEL,
        "mode": "polling",
    }


@app.post("/telegram/webhook")
async def webhook(request: Request) -> dict[str, bool]:
    # Kept only for compatibility if a host sends webhook requests.
    if not configured():
        raise HTTPException(status_code=503, detail="Bot is not configured")
    update = await request.json()
    asyncio.create_task(handle_update(update))
    return {"ok": True}
